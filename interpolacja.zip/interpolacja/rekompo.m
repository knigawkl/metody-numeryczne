clc
x = [-2 -1 1 2 4];
y = [-6 0 0 6 60];
xx = [-2:0.02:4];
yy = newton(xx,x,y);
clf,plot(xx,yy,'b-',x,y,'*'),grid on
%%
function yy = newtonp(xx,x,y)
N = size(x,2);
DD = zeros(N,N);
DD(1:N,1)=y';
for k=2:N
for m=1:N+1-k
DD(m,k) = (DD(m+1,k-1) - DD(m,k-1))/(x(m+k-1)-x(m));
end
end
r = DD(1,:);
cn = r(N);
for k=N-1:-1:1
cn = [cn r(k)] - [0 cn*x(k)];
end
yy = polyval(cn,xx);
end
%%
function y = newton(x, points_x, points_y)
    n = size(points_x, 2);
    D = zeros(n,n);
    D(1:n,1)=points_y';
    for i=2:n
        for j=1:n+1-i
            D(j,i) = (D(j+1,i-1) - D(j,i-1))/(points_x(j+i-1)-points_x(j));
        end
    end
    r = D(1,:);
    p = r(n);
    for i=n-1:-1:1
        p = [p r(i)] - [0 p*points_x(i)];
    end
    y = polyval(p,x);
end
